#Leap year
"""
Year % 4==0&
Year % 100!=0/
Year % 400==0
" " "
def is LeapYear (Year):
  if(Year%4==0andYear%100!=0)orYear%400==0

return True
else:
return False
Year=int(input("Enter a Year:"))
if is Leap Year (Year):
print('{} is a Leap Year.'.format(Year))
else:
print('{} is not a Leap Year.'.format at (Year))